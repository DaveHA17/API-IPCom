package com.init.empleados.rest;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.init.empleados.BD.DB;
import com.init.empleados.IPCom.empleado;

@RestController
@RequestMapping("Empleados")
public class empleadosREST {
	
	@Autowired
	private DB db;
	
	@GetMapping //Ver todos los empleados
	public ResponseEntity<List<empleado>> getEmpleado(){
		List<empleado> empleados= db.findAll();	
		return  ResponseEntity.ok(empleados);
	}

	
	@RequestMapping(value="{id}") //Busqueda de empleado por ID
	public ResponseEntity<empleado> getEmpleadoById(@PathVariable("id") Long Id) {
		Optional<empleado> optionalEmpleados= db.findById(Id);
		if(optionalEmpleados.isPresent()) {
			return  ResponseEntity.ok(optionalEmpleados.get());
		} else {
			
			return ResponseEntity.noContent().build();
		}
	}
	

		@PostMapping //Agregar un nuevo Empleado
		public ResponseEntity<empleado> creatEmpleado(@RequestBody empleado empleado){
			empleado newEmpleado = db.save(empleado);
			return ResponseEntity.ok(newEmpleado);
		
		}
		
		@DeleteMapping(value="borrar/{id}") //Borrar un Empleado si se vuelve inactivo.
		public ResponseEntity<Void> deleteEmpleado(@PathVariable("id") Long id){
			db.deleteById(id);
			return ResponseEntity.ok(null);
			
		}
		
		@PutMapping//Actualizar datos de empleado
		public ResponseEntity<empleado> updateEmpleado(@RequestBody empleado empleado){
			Optional<empleado> optionalEmpleados= db.findById(empleado.getId());
			if(optionalEmpleados.isPresent()) {
				empleado updateEmpleado = optionalEmpleados.get();
				updateEmpleado.setFirstName(empleado.getFirstName());
				updateEmpleado.setMiddleInitial(empleado.getMiddleInitial());
				updateEmpleado.setLastName(empleado.getLastName());
				updateEmpleado.setDateBirth(empleado.getDateBirth());
				updateEmpleado.setDateEmp(empleado.getDateEmp());
				updateEmpleado.setStatus(empleado.getStatus());
				db.save(updateEmpleado);
				return  ResponseEntity.ok(updateEmpleado);
			} else {
				
				return ResponseEntity.noContent().build();
			}
		}
		
	
}


















