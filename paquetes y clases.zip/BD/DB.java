package com.init.empleados.BD;

import org.springframework.data.jpa.repository.JpaRepository;

import com.init.empleados.IPCom.empleado;

public interface DB extends JpaRepository<empleado,Long> {

}
