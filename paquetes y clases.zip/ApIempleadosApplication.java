package com.init.empleados;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.init.empleados.seguridadJwt.autorizacion;//es.softtek.jwtDemo.security.JWTAuthorizationFilter;
import com.init.empleados.IPCom.empleado;


@SpringBootApplication
public class ApIempleadosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApIempleadosApplication.class, args);
	}
	
	@EnableWebSecurity
	@Configuration
	class WebSecurityConfig extends WebSecurityConfigurerAdapter {

		@Override
		protected void configure(HttpSecurity http) throws Exception {
			http.csrf().disable()
				.addFilterAfter(new autorizacion(), UsernamePasswordAuthenticationFilter.class)
				.authorizeRequests()
				.antMatchers(HttpMethod.POST,"/user").permitAll()
				.antMatchers(HttpMethod.GET,"/Empleados","/Empleados/{id}").permitAll()
				.anyRequest().authenticated();
		}
	}

}