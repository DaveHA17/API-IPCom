package com.init.empleados.IPCom;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "Empleados")
public class empleado {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;
	
	@Column(name="firstName", nullable=false, length=12)
	private String FirstName;
	
	@Column(name="middleInitial", length=2)
	private String MiddleInitial;
	
	@Column(name="lastName", nullable=false, length=12)
	private String LastName;
	
	@Column(name= "dateBirth", nullable=false, length=10)
	private String DateBirth;
	
	@Column(name="dateEmp", nullable=false, length=10) // formato dd/mm/aaaa
	private String DateEmp;
	
	@Column (name="status", nullable=false, length=8)
	private String Status= "Activo;" ;//cuando lo ingrese desde POST
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getMiddleInitial() {
		return MiddleInitial;
	}
	public void setMiddleInitial(String middleInitial) {
		MiddleInitial = middleInitial;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getDateBirth() {
		return DateBirth;
	}
	public void setDateBirth(String dateBirth) {
		DateBirth = dateBirth;
	}
	public String getDateEmp() {
		return DateEmp;
	}
	public void setDateEmp(String dateEmp) {
		DateEmp = dateEmp;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	
	
}
